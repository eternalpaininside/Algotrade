package usersservice

import (
	"context"

	"github.com/eternalpaininside/Algotrade.git/backend/internal/core/domain"
)

type UserService struct {
	repository UserRepository
}

type UserRepository interface {
	CreateUser(
		ctx context.Context,
		user domain.User,
	) (domain.User, error)
	GetUsers(
		ctx context.Context,
		limit, offset *int,
	) ([]domain.User, error)
}

func NewUserService(
	repository UserRepository,
) *UserService {
	return &UserService{
		repository: repository,
	}
}
